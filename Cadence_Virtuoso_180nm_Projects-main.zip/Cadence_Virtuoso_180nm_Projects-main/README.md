# Cadence_Virtuoso_180nm_Projects
 Schematic, Layout Design & Simulation in 180nm Technology
